<!DOCTYPE html>
<html>
<head>
	<title>Form Proccesing Examples</title>
	<style media="screen">
		input[type="text"]{
			font-size: 14pt;
			font-family: Arial, serif;
			color: green;
			font-weight: bold;
		}
	</style>
</head>
<body>
	<h1> Buy Your Way to a Better Education! </h1>
	<form action="post.php" method="post">
	<fieldset>
		<legend>Basic Details</legend>
		<dl>
			<dt> Search Criteria </dt>
			<dd> <input type="text" name="q"> </dd>

			<dt> Age </dt>
			<dd> <input type="text" name="age"> </dd>

			<dt> Gender </dt>
			<dd> <input type="checkbox" name="gender" checked> </dd>
		</dl>
	</fieldset>

	<fieldset>
		<legend>Additional Details</legend>
		<dl>
			<dt> Profession </dt>
			<dd> 
				Student <input type="radio" name="profession" value="Student" checked> 
				Professor <input type="radio" name="profession" value="Professor"> 
				Admin <input type="radio" name="profession" value="Admin"> 
			</dd>

			<dt>Courses</dt>
			<dd>
				<select multiple="" name="course[]">
				<optgroup label="Technical Subjects">
					<option value="IP"> Internet Programming </option>
					<option value="EM"> Engineering Maths </option>
					<option value="SP"> System Programming </option>
				</optgroup> 

				<optgroup label="Non-Technical">
					<option value="AE"> Academic English </option>
					<option value="BK"> Basic Korean </option>
					<option value="H"> History </option>
				</optgroup>
				</select>
			</dd>			
		</dl>
	</fieldset>

		<input type="hidden" name="userID" value="0011">
		<input type="submit" value="Search!">
		<input type="reset" value="Reset!">


	</form>

</body>
</html>