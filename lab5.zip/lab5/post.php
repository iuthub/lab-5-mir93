<!DOCTYPE html>
<html>
<head>
	<title>Received Using POST</title>
</head>
<body>
	<h1>Value Received</h1>
	<ul>
		<li>Search Query: <?= $_REQUEST["q"] ?> </li>
		<li>Age: <?= $_REQUEST["age"] ?> </li>
		<li>Gender: <?= $_REQUEST["gender"] ?> </li>
	</ul>

</body>
</html>