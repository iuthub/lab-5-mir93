<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Buy Your Way to a Better Education!</title>
		<link href="buyagrade.css" type="text/css" rel="stylesheet" />
	</head>
	
	<body>
		<?php
			if (!isset($_POST['name'])||!isset($_POST['section'])||!isset($_POST['cardname'])||!isset($_POST['cardtype'])) {
		 ?>
		 <h1> Sorry</h1>
		 <p>
		 	You didn't fill  out the form completely. <a href="buyagrade.html">Try again?</a></p>
		<?php }else { ?>

		<h1>Thanks, sucker!</h1>
		<p>
			Your information has been recorded.
		</p>
		<dl>
			<dt>Name</dt>
			<dd>
				<?=$_POST['name']?>
			</dd>
			<dt>Section</dt>
			<dd>
				<?=$_POST['section']?>
			</dd>
			<dt>Credit Card</dt>
			<dd>
				<?=$_POST['cardname']?> <?=$_POST['cardtype'] ?>
			</dd>
		</dl>
		<?php
		$data = $_POST['name'].";".$_POST['section'].";".$_POST["cardname"].";".$_POST['cardtype']."\n";
		file_put_contents("sukers.txt", $data, FILE_APPEND);
		?>
		<p>Here are all suckers who have submitted here:	</p>
		<pre>
<?=file_get_contents("sukers.txt")?>
		</pre>
		<?php }?>
	</body>
</html>